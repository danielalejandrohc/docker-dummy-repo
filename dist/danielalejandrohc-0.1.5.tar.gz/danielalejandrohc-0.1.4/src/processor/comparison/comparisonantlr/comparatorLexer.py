# Generated from comparator.g4 by ANTLR 4.7.1
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2\31")
        buf.write("\u0100\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write("\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write("\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23")
        buf.write("\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30")
        buf.write("\3\2\3\2\3\3\3\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4F\n\4\3\5\3\5\3\5\3\5\3")
        buf.write("\5\3\5\3\5\3\5\3\5\5\5Q\n\5\3\6\3\6\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\5\7]\n\7\3\b\3\b\3\b\3\b\3\b\3\b\5\be\n")
        buf.write("\b\3\b\6\bh\n\b\r\b\16\bi\3\t\3\t\3\t\5\to\n\t\3\t\5\t")
        buf.write("r\n\t\3\n\3\n\3\n\5\nw\n\n\3\n\3\n\5\n{\n\n\3\n\3\n\5")
        buf.write("\n\177\n\n\3\n\3\n\5\n\u0083\n\n\3\n\5\n\u0086\n\n\3\n")
        buf.write("\3\n\5\n\u008a\n\n\3\13\3\13\3\13\5\13\u008f\n\13\3\13")
        buf.write("\3\13\5\13\u0093\n\13\3\13\3\13\5\13\u0097\n\13\3\13\3")
        buf.write("\13\5\13\u009b\n\13\3\13\5\13\u009e\n\13\5\13\u00a0\n")
        buf.write("\13\3\13\3\13\3\f\3\f\7\f\u00a6\n\f\f\f\16\f\u00a9\13")
        buf.write("\f\3\r\3\r\3\r\5\r\u00ae\n\r\3\r\3\r\7\r\u00b2\n\r\f\r")
        buf.write("\16\r\u00b5\13\r\3\r\3\r\7\r\u00b9\n\r\f\r\16\r\u00bc")
        buf.write("\13\r\3\r\3\r\3\16\3\16\7\16\u00c2\n\16\f\16\16\16\u00c5")
        buf.write("\13\16\3\16\3\16\3\17\3\17\3\17\3\17\3\20\6\20\u00ce\n")
        buf.write("\20\r\20\16\20\u00cf\3\21\6\21\u00d3\n\21\r\21\16\21\u00d4")
        buf.write("\3\21\3\21\6\21\u00d9\n\21\r\21\16\21\u00da\5\21\u00dd")
        buf.write("\n\21\3\22\5\22\u00e0\n\22\3\22\3\22\3\22\3\22\3\22\3")
        buf.write("\22\3\22\3\22\3\22\5\22\u00eb\n\22\3\22\5\22\u00ee\n\22")
        buf.write("\3\23\3\23\3\24\3\24\3\25\3\25\3\26\3\26\3\27\3\27\3\30")
        buf.write("\6\30\u00fb\n\30\r\30\16\30\u00fc\3\30\3\30\3\u00c3\2")
        buf.write("\31\3\3\5\4\7\5\t\6\13\7\r\b\17\t\21\n\23\13\25\f\27\r")
        buf.write("\31\16\33\17\35\20\37\21!\22#\23%\24\'\25)\26+\27-\30")
        buf.write("/\31\3\2\17\4\2HHhh\4\2CCcc\4\2NNnn\4\2UUuu\4\2GGgg\4")
        buf.write("\2VVvv\4\2TTtt\4\2WWww\4\2>>@@\4\2C\\c|\7\2//\62;C\\a")
        buf.write("ac|\3\2\62;\5\2\13\f\16\17\"\"\2\u0126\2\3\3\2\2\2\2\5")
        buf.write("\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13\3\2\2\2\2\r\3\2")
        buf.write("\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2\23\3\2\2\2\2\25\3\2\2")
        buf.write("\2\2\27\3\2\2\2\2\31\3\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2")
        buf.write("\2\37\3\2\2\2\2!\3\2\2\2\2#\3\2\2\2\2%\3\2\2\2\2\'\3\2")
        buf.write("\2\2\2)\3\2\2\2\2+\3\2\2\2\2-\3\2\2\2\2/\3\2\2\2\3\61")
        buf.write("\3\2\2\2\5\63\3\2\2\2\7E\3\2\2\2\tP\3\2\2\2\13R\3\2\2")
        buf.write("\2\r\\\3\2\2\2\17^\3\2\2\2\21k\3\2\2\2\23s\3\2\2\2\25")
        buf.write("\u008b\3\2\2\2\27\u00a3\3\2\2\2\31\u00aa\3\2\2\2\33\u00bf")
        buf.write("\3\2\2\2\35\u00c8\3\2\2\2\37\u00cd\3\2\2\2!\u00d2\3\2")
        buf.write("\2\2#\u00df\3\2\2\2%\u00ef\3\2\2\2\'\u00f1\3\2\2\2)\u00f3")
        buf.write("\3\2\2\2+\u00f5\3\2\2\2-\u00f7\3\2\2\2/\u00fa\3\2\2\2")
        buf.write("\61\62\7*\2\2\62\4\3\2\2\2\63\64\7+\2\2\64\6\3\2\2\2\65")
        buf.write("\66\7g\2\2\66\67\7z\2\2\678\7k\2\289\7u\2\29F\7v\2\2:")
        buf.write(";\7g\2\2;<\7z\2\2<=\7k\2\2=>\7u\2\2>?\7v\2\2?F\7u\2\2")
        buf.write("@A\7e\2\2AB\7q\2\2BC\7w\2\2CD\7p\2\2DF\7v\2\2E\65\3\2")
        buf.write("\2\2E:\3\2\2\2E@\3\2\2\2F\b\3\2\2\2GH\t\2\2\2HI\t\3\2")
        buf.write("\2IJ\t\4\2\2JK\t\5\2\2KQ\t\6\2\2LM\t\7\2\2MN\t\b\2\2N")
        buf.write("O\t\t\2\2OQ\t\6\2\2PG\3\2\2\2PL\3\2\2\2Q\n\3\2\2\2RS\7")
        buf.write("-\2\2S\f\3\2\2\2T]\t\n\2\2UV\7@\2\2V]\7?\2\2WX\7>\2\2")
        buf.write("X]\7?\2\2YZ\7#\2\2Z]\7?\2\2[]\7?\2\2\\T\3\2\2\2\\U\3\2")
        buf.write("\2\2\\W\3\2\2\2\\Y\3\2\2\2\\[\3\2\2\2]\16\3\2\2\2^_\7")
        buf.write("}\2\2_`\5\37\20\2`g\7\177\2\2ad\7\60\2\2be\5\21\t\2ce")
        buf.write("\5\23\n\2db\3\2\2\2dc\3\2\2\2eh\3\2\2\2fh\5\25\13\2ga")
        buf.write("\3\2\2\2gf\3\2\2\2hi\3\2\2\2ig\3\2\2\2ij\3\2\2\2j\20\3")
        buf.write("\2\2\2kq\5\27\f\2ln\7]\2\2mo\5\37\20\2nm\3\2\2\2no\3\2")
        buf.write("\2\2op\3\2\2\2pr\7_\2\2ql\3\2\2\2qr\3\2\2\2r\22\3\2\2")
        buf.write("\2s\u0089\5\27\f\2tv\7]\2\2uw\5%\23\2vu\3\2\2\2vw\3\2")
        buf.write("\2\2wx\3\2\2\2xz\5\27\f\2y{\5%\23\2zy\3\2\2\2z{\3\2\2")
        buf.write("\2{|\3\2\2\2|~\7?\2\2}\177\5%\23\2~}\3\2\2\2~\177\3\2")
        buf.write("\2\2\177\u0082\3\2\2\2\u0080\u0083\5\37\20\2\u0081\u0083")
        buf.write("\5\27\f\2\u0082\u0080\3\2\2\2\u0082\u0081\3\2\2\2\u0083")
        buf.write("\u0085\3\2\2\2\u0084\u0086\5%\23\2\u0085\u0084\3\2\2\2")
        buf.write("\u0085\u0086\3\2\2\2\u0086\u0087\3\2\2\2\u0087\u0088\7")
        buf.write("_\2\2\u0088\u008a\3\2\2\2\u0089t\3\2\2\2\u0089\u008a\3")
        buf.write("\2\2\2\u008a\24\3\2\2\2\u008b\u009f\7]\2\2\u008c\u00a0")
        buf.write("\5\37\20\2\u008d\u008f\5%\23\2\u008e\u008d\3\2\2\2\u008e")
        buf.write("\u008f\3\2\2\2\u008f\u0090\3\2\2\2\u0090\u0092\5\27\f")
        buf.write("\2\u0091\u0093\5%\23\2\u0092\u0091\3\2\2\2\u0092\u0093")
        buf.write("\3\2\2\2\u0093\u0094\3\2\2\2\u0094\u0096\7?\2\2\u0095")
        buf.write("\u0097\5%\23\2\u0096\u0095\3\2\2\2\u0096\u0097\3\2\2\2")
        buf.write("\u0097\u009a\3\2\2\2\u0098\u009b\5\37\20\2\u0099\u009b")
        buf.write("\5\27\f\2\u009a\u0098\3\2\2\2\u009a\u0099\3\2\2\2\u009b")
        buf.write("\u009d\3\2\2\2\u009c\u009e\5%\23\2\u009d\u009c\3\2\2\2")
        buf.write("\u009d\u009e\3\2\2\2\u009e\u00a0\3\2\2\2\u009f\u008c\3")
        buf.write("\2\2\2\u009f\u008e\3\2\2\2\u009f\u00a0\3\2\2\2\u00a0\u00a1")
        buf.write("\3\2\2\2\u00a1\u00a2\7_\2\2\u00a2\26\3\2\2\2\u00a3\u00a7")
        buf.write("\t\13\2\2\u00a4\u00a6\t\f\2\2\u00a5\u00a4\3\2\2\2\u00a6")
        buf.write("\u00a9\3\2\2\2\u00a7\u00a5\3\2\2\2\u00a7\u00a8\3\2\2\2")
        buf.write("\u00a8\30\3\2\2\2\u00a9\u00a7\3\2\2\2\u00aa\u00ad\5\'")
        buf.write("\24\2\u00ab\u00ae\5#\22\2\u00ac\u00ae\5\35\17\2\u00ad")
        buf.write("\u00ab\3\2\2\2\u00ad\u00ac\3\2\2\2\u00ae\u00ba\3\2\2\2")
        buf.write("\u00af\u00b3\7.\2\2\u00b0\u00b2\5/\30\2\u00b1\u00b0\3")
        buf.write("\2\2\2\u00b2\u00b5\3\2\2\2\u00b3\u00b1\3\2\2\2\u00b3\u00b4")
        buf.write("\3\2\2\2\u00b4\u00b6\3\2\2\2\u00b5\u00b3\3\2\2\2\u00b6")
        buf.write("\u00b9\5#\22\2\u00b7\u00b9\5\35\17\2\u00b8\u00af\3\2\2")
        buf.write("\2\u00b8\u00b7\3\2\2\2\u00b9\u00bc\3\2\2\2\u00ba\u00b8")
        buf.write("\3\2\2\2\u00ba\u00bb\3\2\2\2\u00bb\u00bd\3\2\2\2\u00bc")
        buf.write("\u00ba\3\2\2\2\u00bd\u00be\5)\25\2\u00be\32\3\2\2\2\u00bf")
        buf.write("\u00c3\5+\26\2\u00c0\u00c2\13\2\2\2\u00c1\u00c0\3\2\2")
        buf.write("\2\u00c2\u00c5\3\2\2\2\u00c3\u00c4\3\2\2\2\u00c3\u00c1")
        buf.write("\3\2\2\2\u00c4\u00c6\3\2\2\2\u00c5\u00c3\3\2\2\2\u00c6")
        buf.write("\u00c7\5-\27\2\u00c7\34\3\2\2\2\u00c8\u00c9\5%\23\2\u00c9")
        buf.write("\u00ca\5\27\f\2\u00ca\u00cb\5%\23\2\u00cb\36\3\2\2\2\u00cc")
        buf.write("\u00ce\t\r\2\2\u00cd\u00cc\3\2\2\2\u00ce\u00cf\3\2\2\2")
        buf.write("\u00cf\u00cd\3\2\2\2\u00cf\u00d0\3\2\2\2\u00d0 \3\2\2")
        buf.write("\2\u00d1\u00d3\t\r\2\2\u00d2\u00d1\3\2\2\2\u00d3\u00d4")
        buf.write("\3\2\2\2\u00d4\u00d2\3\2\2\2\u00d4\u00d5\3\2\2\2\u00d5")
        buf.write("\u00dc\3\2\2\2\u00d6\u00d8\7\60\2\2\u00d7\u00d9\t\r\2")
        buf.write("\2\u00d8\u00d7\3\2\2\2\u00d9\u00da\3\2\2\2\u00da\u00d8")
        buf.write("\3\2\2\2\u00da\u00db\3\2\2\2\u00db\u00dd\3\2\2\2\u00dc")
        buf.write("\u00d6\3\2\2\2\u00dc\u00dd\3\2\2\2\u00dd\"\3\2\2\2\u00de")
        buf.write("\u00e0\5%\23\2\u00df\u00de\3\2\2\2\u00df\u00e0\3\2\2\2")
        buf.write("\u00e0\u00e1\3\2\2\2\u00e1\u00e2\5\37\20\2\u00e2\u00e3")
        buf.write("\7\60\2\2\u00e3\u00e4\5\37\20\2\u00e4\u00e5\7\60\2\2\u00e5")
        buf.write("\u00e6\5\37\20\2\u00e6\u00e7\7\60\2\2\u00e7\u00ea\5\37")
        buf.write("\20\2\u00e8\u00e9\7\61\2\2\u00e9\u00eb\5\37\20\2\u00ea")
        buf.write("\u00e8\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb\u00ed\3\2\2\2")
        buf.write("\u00ec\u00ee\5%\23\2\u00ed\u00ec\3\2\2\2\u00ed\u00ee\3")
        buf.write("\2\2\2\u00ee$\3\2\2\2\u00ef\u00f0\7)\2\2\u00f0&\3\2\2")
        buf.write("\2\u00f1\u00f2\7]\2\2\u00f2(\3\2\2\2\u00f3\u00f4\7_\2")
        buf.write("\2\u00f4*\3\2\2\2\u00f5\u00f6\7}\2\2\u00f6,\3\2\2\2\u00f7")
        buf.write("\u00f8\7\177\2\2\u00f8.\3\2\2\2\u00f9\u00fb\t\16\2\2\u00fa")
        buf.write("\u00f9\3\2\2\2\u00fb\u00fc\3\2\2\2\u00fc\u00fa\3\2\2\2")
        buf.write("\u00fc\u00fd\3\2\2\2\u00fd\u00fe\3\2\2\2\u00fe\u00ff\b")
        buf.write("\30\2\2\u00ff\60\3\2\2\2%\2EP\\dginqvz~\u0082\u0085\u0089")
        buf.write("\u008e\u0092\u0096\u009a\u009d\u009f\u00a7\u00ad\u00b3")
        buf.write("\u00b8\u00ba\u00c3\u00cf\u00d4\u00da\u00dc\u00df\u00ea")
        buf.write("\u00ed\u00fc\3\b\2\2")
        return buf.getvalue()


class comparatorLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    T__0 = 1
    T__1 = 2
    METHOD = 3
    BOOL = 4
    OP = 5
    COMP = 6
    FMT1 = 7
    ATTRFMT1 = 8
    ATTRFMT2 = 9
    ATTRFMT3 = 10
    STRING = 11
    ARRSTRING = 12
    DICTSTRING = 13
    QUOTESTRING = 14
    NUMBER = 15
    FNUMBER = 16
    IPADDRESS = 17
    QUOTE = 18
    SQOPEN = 19
    SQCLOSE = 20
    FLOPEN = 21
    FLCLOSE = 22
    WS = 23

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
            "'('", "')'", "'+'", "'''", "'['", "']'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>",
            "METHOD", "BOOL", "OP", "COMP", "FMT1", "ATTRFMT1", "ATTRFMT2", 
            "ATTRFMT3", "STRING", "ARRSTRING", "DICTSTRING", "QUOTESTRING", 
            "NUMBER", "FNUMBER", "IPADDRESS", "QUOTE", "SQOPEN", "SQCLOSE", 
            "FLOPEN", "FLCLOSE", "WS" ]

    ruleNames = [ "T__0", "T__1", "METHOD", "BOOL", "OP", "COMP", "FMT1", 
                  "ATTRFMT1", "ATTRFMT2", "ATTRFMT3", "STRING", "ARRSTRING", 
                  "DICTSTRING", "QUOTESTRING", "NUMBER", "FNUMBER", "IPADDRESS", 
                  "QUOTE", "SQOPEN", "SQCLOSE", "FLOPEN", "FLCLOSE", "WS" ]

    grammarFileName = "comparator.g4"

    def __init__(self, input=None, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.1")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None



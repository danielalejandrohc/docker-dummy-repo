# Generated from comparator.g4 by ANTLR 4.7.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\31")
        buf.write("\u00c3\4\2\t\2\3\2\5\2\6\n\2\3\2\5\2\t\n\2\3\2\5\2\f\n")
        buf.write("\2\3\2\5\2\17\n\2\3\2\3\2\5\2\23\n\2\3\2\3\2\5\2\27\n")
        buf.write("\2\3\2\5\2\32\n\2\3\2\3\2\5\2\36\n\2\7\2 \n\2\f\2\16\2")
        buf.write("#\13\2\3\2\5\2&\n\2\3\2\3\2\3\2\3\2\3\2\3\2\5\2.\n\2\3")
        buf.write("\2\5\2\61\n\2\3\2\5\2\64\n\2\3\2\3\2\5\28\n\2\3\2\3\2")
        buf.write("\5\2<\n\2\3\2\5\2?\n\2\3\2\3\2\5\2C\n\2\7\2E\n\2\f\2\16")
        buf.write("\2H\13\2\3\2\3\2\5\2L\n\2\3\2\5\2O\n\2\3\2\3\2\3\2\7\2")
        buf.write("T\n\2\f\2\16\2W\13\2\3\2\5\2Z\n\2\5\2\\\n\2\3\2\3\2\3")
        buf.write("\2\3\2\5\2b\n\2\3\2\3\2\3\2\3\2\5\2h\n\2\3\2\3\2\3\2\3")
        buf.write("\2\3\2\3\2\3\2\7\2q\n\2\f\2\16\2t\13\2\3\2\5\2w\n\2\3")
        buf.write("\2\3\2\3\2\3\2\3\2\7\2~\n\2\f\2\16\2\u0081\13\2\3\2\3")
        buf.write("\2\3\2\3\2\3\2\5\2\u0088\n\2\3\2\3\2\3\2\3\2\3\2\7\2\u008f")
        buf.write("\n\2\f\2\16\2\u0092\13\2\3\2\3\2\3\2\5\2\u0097\n\2\3\2")
        buf.write("\3\2\3\2\3\2\3\2\7\2\u009e\n\2\f\2\16\2\u00a1\13\2\3\2")
        buf.write("\3\2\3\2\5\2\u00a6\n\2\3\2\3\2\3\2\3\2\3\2\7\2\u00ad\n")
        buf.write("\2\f\2\16\2\u00b0\13\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\7\2")
        buf.write("\u00b9\n\2\f\2\16\2\u00bc\13\2\3\2\5\2\u00bf\n\2\5\2\u00c1")
        buf.write("\n\2\3\2\2\2\3\2\2\2\2\u00f5\2\u00c0\3\2\2\2\4\6\7\5\2")
        buf.write("\2\5\4\3\2\2\2\5\6\3\2\2\2\6\b\3\2\2\2\7\t\7\3\2\2\b\7")
        buf.write("\3\2\2\2\b\t\3\2\2\2\t\13\3\2\2\2\n\f\7\5\2\2\13\n\3\2")
        buf.write("\2\2\13\f\3\2\2\2\f\16\3\2\2\2\r\17\7\3\2\2\16\r\3\2\2")
        buf.write("\2\16\17\3\2\2\2\17\20\3\2\2\2\20\22\7\t\2\2\21\23\7\4")
        buf.write("\2\2\22\21\3\2\2\2\22\23\3\2\2\2\23!\3\2\2\2\24\26\7\7")
        buf.write("\2\2\25\27\7\5\2\2\26\25\3\2\2\2\26\27\3\2\2\2\27\31\3")
        buf.write("\2\2\2\30\32\7\3\2\2\31\30\3\2\2\2\31\32\3\2\2\2\32\33")
        buf.write("\3\2\2\2\33\35\7\t\2\2\34\36\7\4\2\2\35\34\3\2\2\2\35")
        buf.write("\36\3\2\2\2\36 \3\2\2\2\37\24\3\2\2\2 #\3\2\2\2!\37\3")
        buf.write("\2\2\2!\"\3\2\2\2\"%\3\2\2\2#!\3\2\2\2$&\7\4\2\2%$\3\2")
        buf.write("\2\2%&\3\2\2\2&-\3\2\2\2\'(\7\b\2\2(.\7\21\2\2).\7\22")
        buf.write("\2\2*.\7\6\2\2+.\7\16\2\2,.\7\17\2\2-\'\3\2\2\2-)\3\2")
        buf.write("\2\2-*\3\2\2\2-+\3\2\2\2-,\3\2\2\2-.\3\2\2\2.\u00c1\3")
        buf.write("\2\2\2/\61\7\5\2\2\60/\3\2\2\2\60\61\3\2\2\2\61\63\3\2")
        buf.write("\2\2\62\64\7\3\2\2\63\62\3\2\2\2\63\64\3\2\2\2\64\65\3")
        buf.write("\2\2\2\65\67\7\t\2\2\668\7\4\2\2\67\66\3\2\2\2\678\3\2")
        buf.write("\2\28F\3\2\2\29;\7\7\2\2:<\7\5\2\2;:\3\2\2\2;<\3\2\2\2")
        buf.write("<>\3\2\2\2=?\7\3\2\2>=\3\2\2\2>?\3\2\2\2?@\3\2\2\2@B\7")
        buf.write("\t\2\2AC\7\4\2\2BA\3\2\2\2BC\3\2\2\2CE\3\2\2\2D9\3\2\2")
        buf.write("\2EH\3\2\2\2FD\3\2\2\2FG\3\2\2\2G[\3\2\2\2HF\3\2\2\2I")
        buf.write("K\7\b\2\2JL\7\5\2\2KJ\3\2\2\2KL\3\2\2\2LN\3\2\2\2MO\7")
        buf.write("\3\2\2NM\3\2\2\2NO\3\2\2\2OP\3\2\2\2PU\7\t\2\2QR\7\7\2")
        buf.write("\2RT\7\t\2\2SQ\3\2\2\2TW\3\2\2\2US\3\2\2\2UV\3\2\2\2V")
        buf.write("Y\3\2\2\2WU\3\2\2\2XZ\7\4\2\2YX\3\2\2\2YZ\3\2\2\2Z\\\3")
        buf.write("\2\2\2[I\3\2\2\2[\\\3\2\2\2\\\u00c1\3\2\2\2]a\7\t\2\2")
        buf.write("^_\7\b\2\2_b\7\21\2\2`b\7\22\2\2a^\3\2\2\2a`\3\2\2\2a")
        buf.write("b\3\2\2\2b\u00c1\3\2\2\2cg\7\t\2\2de\7\b\2\2eh\7\23\2")
        buf.write("\2fh\7\r\2\2gd\3\2\2\2gf\3\2\2\2gh\3\2\2\2h\u00c1\3\2")
        buf.write("\2\2iv\7\t\2\2jk\7\b\2\2kl\7\5\2\2lm\7\3\2\2mr\7\t\2\2")
        buf.write("no\7\7\2\2oq\7\t\2\2pn\3\2\2\2qt\3\2\2\2rp\3\2\2\2rs\3")
        buf.write("\2\2\2su\3\2\2\2tr\3\2\2\2uw\7\4\2\2vj\3\2\2\2vw\3\2\2")
        buf.write("\2w\u00c1\3\2\2\2xy\7\5\2\2yz\7\3\2\2z\177\7\t\2\2{|\7")
        buf.write("\7\2\2|~\7\t\2\2}{\3\2\2\2~\u0081\3\2\2\2\177}\3\2\2\2")
        buf.write("\177\u0080\3\2\2\2\u0080\u0082\3\2\2\2\u0081\177\3\2\2")
        buf.write("\2\u0082\u0087\7\4\2\2\u0083\u0084\7\b\2\2\u0084\u0088")
        buf.write("\7\21\2\2\u0085\u0088\7\22\2\2\u0086\u0088\7\6\2\2\u0087")
        buf.write("\u0083\3\2\2\2\u0087\u0085\3\2\2\2\u0087\u0086\3\2\2\2")
        buf.write("\u0087\u0088\3\2\2\2\u0088\u00c1\3\2\2\2\u0089\u008a\7")
        buf.write("\5\2\2\u008a\u008b\7\3\2\2\u008b\u0090\7\t\2\2\u008c\u008d")
        buf.write("\7\7\2\2\u008d\u008f\7\t\2\2\u008e\u008c\3\2\2\2\u008f")
        buf.write("\u0092\3\2\2\2\u0090\u008e\3\2\2\2\u0090\u0091\3\2\2\2")
        buf.write("\u0091\u0093\3\2\2\2\u0092\u0090\3\2\2\2\u0093\u0096\7")
        buf.write("\4\2\2\u0094\u0095\7\b\2\2\u0095\u0097\7\t\2\2\u0096\u0094")
        buf.write("\3\2\2\2\u0096\u0097\3\2\2\2\u0097\u00c1\3\2\2\2\u0098")
        buf.write("\u0099\7\5\2\2\u0099\u009a\7\3\2\2\u009a\u009f\7\t\2\2")
        buf.write("\u009b\u009c\7\7\2\2\u009c\u009e\7\t\2\2\u009d\u009b\3")
        buf.write("\2\2\2\u009e\u00a1\3\2\2\2\u009f\u009d\3\2\2\2\u009f\u00a0")
        buf.write("\3\2\2\2\u00a0\u00a2\3\2\2\2\u00a1\u009f\3\2\2\2\u00a2")
        buf.write("\u00a5\7\4\2\2\u00a3\u00a4\7\b\2\2\u00a4\u00a6\7\r\2\2")
        buf.write("\u00a5\u00a3\3\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\u00c1\3")
        buf.write("\2\2\2\u00a7\u00a8\7\5\2\2\u00a8\u00a9\7\3\2\2\u00a9\u00ae")
        buf.write("\7\t\2\2\u00aa\u00ab\7\7\2\2\u00ab\u00ad\7\t\2\2\u00ac")
        buf.write("\u00aa\3\2\2\2\u00ad\u00b0\3\2\2\2\u00ae\u00ac\3\2\2\2")
        buf.write("\u00ae\u00af\3\2\2\2\u00af\u00b1\3\2\2\2\u00b0\u00ae\3")
        buf.write("\2\2\2\u00b1\u00be\7\4\2\2\u00b2\u00b3\7\b\2\2\u00b3\u00b4")
        buf.write("\7\5\2\2\u00b4\u00b5\7\3\2\2\u00b5\u00ba\7\t\2\2\u00b6")
        buf.write("\u00b7\7\7\2\2\u00b7\u00b9\7\t\2\2\u00b8\u00b6\3\2\2\2")
        buf.write("\u00b9\u00bc\3\2\2\2\u00ba\u00b8\3\2\2\2\u00ba\u00bb\3")
        buf.write("\2\2\2\u00bb\u00bd\3\2\2\2\u00bc\u00ba\3\2\2\2\u00bd\u00bf")
        buf.write("\7\4\2\2\u00be\u00b2\3\2\2\2\u00be\u00bf\3\2\2\2\u00bf")
        buf.write("\u00c1\3\2\2\2\u00c0\5\3\2\2\2\u00c0\60\3\2\2\2\u00c0")
        buf.write("]\3\2\2\2\u00c0c\3\2\2\2\u00c0i\3\2\2\2\u00c0x\3\2\2\2")
        buf.write("\u00c0\u0089\3\2\2\2\u00c0\u0098\3\2\2\2\u00c0\u00a7\3")
        buf.write("\2\2\2\u00c1\3\3\2\2\2\'\5\b\13\16\22\26\31\35!%-\60\63")
        buf.write("\67;>BFKNUY[agrv\177\u0087\u0090\u0096\u009f\u00a5\u00ae")
        buf.write("\u00ba\u00be\u00c0")
        return buf.getvalue()


class comparatorParser ( Parser ):

    grammarFileName = "comparator.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "<INVALID>", "<INVALID>", 
                     "'+'", "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'''", "'['", "']'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "METHOD", "BOOL", 
                      "OP", "COMP", "FMT1", "ATTRFMT1", "ATTRFMT2", "ATTRFMT3", 
                      "STRING", "ARRSTRING", "DICTSTRING", "QUOTESTRING", 
                      "NUMBER", "FNUMBER", "IPADDRESS", "QUOTE", "SQOPEN", 
                      "SQCLOSE", "FLOPEN", "FLCLOSE", "WS" ]

    RULE_expression = 0

    ruleNames =  [ "expression" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    METHOD=3
    BOOL=4
    OP=5
    COMP=6
    FMT1=7
    ATTRFMT1=8
    ATTRFMT2=9
    ATTRFMT3=10
    STRING=11
    ARRSTRING=12
    DICTSTRING=13
    QUOTESTRING=14
    NUMBER=15
    FNUMBER=16
    IPADDRESS=17
    QUOTE=18
    SQOPEN=19
    SQCLOSE=20
    FLOPEN=21
    FLCLOSE=22
    WS=23

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ExpressionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FMT1(self, i:int=None):
            if i is None:
                return self.getTokens(comparatorParser.FMT1)
            else:
                return self.getToken(comparatorParser.FMT1, i)

        def METHOD(self, i:int=None):
            if i is None:
                return self.getTokens(comparatorParser.METHOD)
            else:
                return self.getToken(comparatorParser.METHOD, i)

        def OP(self, i:int=None):
            if i is None:
                return self.getTokens(comparatorParser.OP)
            else:
                return self.getToken(comparatorParser.OP, i)

        def COMP(self):
            return self.getToken(comparatorParser.COMP, 0)

        def NUMBER(self):
            return self.getToken(comparatorParser.NUMBER, 0)

        def FNUMBER(self):
            return self.getToken(comparatorParser.FNUMBER, 0)

        def BOOL(self):
            return self.getToken(comparatorParser.BOOL, 0)

        def ARRSTRING(self):
            return self.getToken(comparatorParser.ARRSTRING, 0)

        def DICTSTRING(self):
            return self.getToken(comparatorParser.DICTSTRING, 0)

        def IPADDRESS(self):
            return self.getToken(comparatorParser.IPADDRESS, 0)

        def STRING(self):
            return self.getToken(comparatorParser.STRING, 0)

        def getRuleIndex(self):
            return comparatorParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)




    def expression(self):

        localctx = comparatorParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_expression)
        self._la = 0 # Token type
        try:
            self.state = 190
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,36,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 3
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 2
                    self.match(comparatorParser.METHOD)


                self.state = 6
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 5
                    self.match(comparatorParser.T__0)


                self.state = 9
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.METHOD:
                    self.state = 8
                    self.match(comparatorParser.METHOD)


                self.state = 12
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.T__0:
                    self.state = 11
                    self.match(comparatorParser.T__0)


                self.state = 14
                self.match(comparatorParser.FMT1)
                self.state = 16
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                if la_ == 1:
                    self.state = 15
                    self.match(comparatorParser.T__1)


                self.state = 31
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==comparatorParser.OP:
                    self.state = 18
                    self.match(comparatorParser.OP)
                    self.state = 20
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.METHOD:
                        self.state = 19
                        self.match(comparatorParser.METHOD)


                    self.state = 23
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.T__0:
                        self.state = 22
                        self.match(comparatorParser.T__0)


                    self.state = 25
                    self.match(comparatorParser.FMT1)
                    self.state = 27
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
                    if la_ == 1:
                        self.state = 26
                        self.match(comparatorParser.T__1)


                    self.state = 33
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 35
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.T__1:
                    self.state = 34
                    self.match(comparatorParser.T__1)


                self.state = 43
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [comparatorParser.COMP]:
                    self.state = 37
                    self.match(comparatorParser.COMP)
                    self.state = 38
                    self.match(comparatorParser.NUMBER)
                    pass
                elif token in [comparatorParser.FNUMBER]:
                    self.state = 39
                    self.match(comparatorParser.FNUMBER)
                    pass
                elif token in [comparatorParser.BOOL]:
                    self.state = 40
                    self.match(comparatorParser.BOOL)
                    pass
                elif token in [comparatorParser.ARRSTRING]:
                    self.state = 41
                    self.match(comparatorParser.ARRSTRING)
                    pass
                elif token in [comparatorParser.DICTSTRING]:
                    self.state = 42
                    self.match(comparatorParser.DICTSTRING)
                    pass
                elif token in [comparatorParser.EOF]:
                    pass
                else:
                    pass
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 46
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.METHOD:
                    self.state = 45
                    self.match(comparatorParser.METHOD)


                self.state = 49
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.T__0:
                    self.state = 48
                    self.match(comparatorParser.T__0)


                self.state = 51
                self.match(comparatorParser.FMT1)
                self.state = 53
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.T__1:
                    self.state = 52
                    self.match(comparatorParser.T__1)


                self.state = 68
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==comparatorParser.OP:
                    self.state = 55
                    self.match(comparatorParser.OP)
                    self.state = 57
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.METHOD:
                        self.state = 56
                        self.match(comparatorParser.METHOD)


                    self.state = 60
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.T__0:
                        self.state = 59
                        self.match(comparatorParser.T__0)


                    self.state = 62
                    self.match(comparatorParser.FMT1)
                    self.state = 64
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.T__1:
                        self.state = 63
                        self.match(comparatorParser.T__1)


                    self.state = 70
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 89
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.COMP:
                    self.state = 71
                    self.match(comparatorParser.COMP)
                    self.state = 73
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.METHOD:
                        self.state = 72
                        self.match(comparatorParser.METHOD)


                    self.state = 76
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.T__0:
                        self.state = 75
                        self.match(comparatorParser.T__0)


                    self.state = 78
                    self.match(comparatorParser.FMT1)
                    self.state = 83
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==comparatorParser.OP:
                        self.state = 79
                        self.match(comparatorParser.OP)
                        self.state = 80
                        self.match(comparatorParser.FMT1)
                        self.state = 85
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 87
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if _la==comparatorParser.T__1:
                        self.state = 86
                        self.match(comparatorParser.T__1)




                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 91
                self.match(comparatorParser.FMT1)
                self.state = 95
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [comparatorParser.COMP]:
                    self.state = 92
                    self.match(comparatorParser.COMP)
                    self.state = 93
                    self.match(comparatorParser.NUMBER)
                    pass
                elif token in [comparatorParser.FNUMBER]:
                    self.state = 94
                    self.match(comparatorParser.FNUMBER)
                    pass
                elif token in [comparatorParser.EOF]:
                    pass
                else:
                    pass
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 97
                self.match(comparatorParser.FMT1)
                self.state = 101
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [comparatorParser.COMP]:
                    self.state = 98
                    self.match(comparatorParser.COMP)
                    self.state = 99
                    self.match(comparatorParser.IPADDRESS)
                    pass
                elif token in [comparatorParser.STRING]:
                    self.state = 100
                    self.match(comparatorParser.STRING)
                    pass
                elif token in [comparatorParser.EOF]:
                    pass
                else:
                    pass
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 103
                self.match(comparatorParser.FMT1)
                self.state = 116
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.COMP:
                    self.state = 104
                    self.match(comparatorParser.COMP)
                    self.state = 105
                    self.match(comparatorParser.METHOD)
                    self.state = 106
                    self.match(comparatorParser.T__0)
                    self.state = 107
                    self.match(comparatorParser.FMT1)
                    self.state = 112
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==comparatorParser.OP:
                        self.state = 108
                        self.match(comparatorParser.OP)
                        self.state = 109
                        self.match(comparatorParser.FMT1)
                        self.state = 114
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 115
                    self.match(comparatorParser.T__1)


                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 118
                self.match(comparatorParser.METHOD)
                self.state = 119
                self.match(comparatorParser.T__0)
                self.state = 120
                self.match(comparatorParser.FMT1)
                self.state = 125
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==comparatorParser.OP:
                    self.state = 121
                    self.match(comparatorParser.OP)
                    self.state = 122
                    self.match(comparatorParser.FMT1)
                    self.state = 127
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 128
                self.match(comparatorParser.T__1)
                self.state = 133
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [comparatorParser.COMP]:
                    self.state = 129
                    self.match(comparatorParser.COMP)
                    self.state = 130
                    self.match(comparatorParser.NUMBER)
                    pass
                elif token in [comparatorParser.FNUMBER]:
                    self.state = 131
                    self.match(comparatorParser.FNUMBER)
                    pass
                elif token in [comparatorParser.BOOL]:
                    self.state = 132
                    self.match(comparatorParser.BOOL)
                    pass
                elif token in [comparatorParser.EOF]:
                    pass
                else:
                    pass
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 135
                self.match(comparatorParser.METHOD)
                self.state = 136
                self.match(comparatorParser.T__0)
                self.state = 137
                self.match(comparatorParser.FMT1)
                self.state = 142
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==comparatorParser.OP:
                    self.state = 138
                    self.match(comparatorParser.OP)
                    self.state = 139
                    self.match(comparatorParser.FMT1)
                    self.state = 144
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 145
                self.match(comparatorParser.T__1)
                self.state = 148
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.COMP:
                    self.state = 146
                    self.match(comparatorParser.COMP)
                    self.state = 147
                    self.match(comparatorParser.FMT1)


                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 150
                self.match(comparatorParser.METHOD)
                self.state = 151
                self.match(comparatorParser.T__0)
                self.state = 152
                self.match(comparatorParser.FMT1)
                self.state = 157
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==comparatorParser.OP:
                    self.state = 153
                    self.match(comparatorParser.OP)
                    self.state = 154
                    self.match(comparatorParser.FMT1)
                    self.state = 159
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 160
                self.match(comparatorParser.T__1)
                self.state = 163
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.COMP:
                    self.state = 161
                    self.match(comparatorParser.COMP)
                    self.state = 162
                    self.match(comparatorParser.STRING)


                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 165
                self.match(comparatorParser.METHOD)
                self.state = 166
                self.match(comparatorParser.T__0)
                self.state = 167
                self.match(comparatorParser.FMT1)
                self.state = 172
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==comparatorParser.OP:
                    self.state = 168
                    self.match(comparatorParser.OP)
                    self.state = 169
                    self.match(comparatorParser.FMT1)
                    self.state = 174
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 175
                self.match(comparatorParser.T__1)
                self.state = 188
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==comparatorParser.COMP:
                    self.state = 176
                    self.match(comparatorParser.COMP)
                    self.state = 177
                    self.match(comparatorParser.METHOD)
                    self.state = 178
                    self.match(comparatorParser.T__0)
                    self.state = 179
                    self.match(comparatorParser.FMT1)
                    self.state = 184
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while _la==comparatorParser.OP:
                        self.state = 180
                        self.match(comparatorParser.OP)
                        self.state = 181
                        self.match(comparatorParser.FMT1)
                        self.state = 186
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 187
                    self.match(comparatorParser.T__1)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





